<?php

namespace LocalTestHook;

class LocalTestHook
{
    //
}
