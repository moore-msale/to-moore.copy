alert('This is a sample file!');
