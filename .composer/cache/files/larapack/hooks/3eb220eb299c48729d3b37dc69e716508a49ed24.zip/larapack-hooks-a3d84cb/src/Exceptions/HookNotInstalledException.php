<?php

namespace Larapack\Hooks\Exceptions;

class HookNotInstalledException extends HookException
{
    //
}
