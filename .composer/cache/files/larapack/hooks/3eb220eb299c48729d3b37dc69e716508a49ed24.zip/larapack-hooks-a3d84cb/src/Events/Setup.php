<?php

namespace Larapack\Hooks\Events;

class Setup
{
    //
}
